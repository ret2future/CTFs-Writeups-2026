"""FastAPI HTTP layer."""
